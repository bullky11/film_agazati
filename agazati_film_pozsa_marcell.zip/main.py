"""
    Olvasd be a mellékelt file (film.txt) tartalmát, majd

    add meg az adatok sorainak a számát (az első sor nélkül)!

    Melyik a legrövidebb film címe?

    Hány darab legalább 110 perces film van?

    Kérd be egy színész nevét, és ajánlj egy pár filmet a készletből, ha tudsz (film címét íratjuk ki, ha van ilyen)! Ha nincs ilyen nevű színész, akkor azt is tudasd!

    A 4-es feladat eredményét írasd ki fájlba is!
"""
import fuggyveny

fuggyveny.beolvas()
fuggyveny.legrovidebb()
fuggyveny.szaz10percesek()
fuggyveny.ajanlas()
